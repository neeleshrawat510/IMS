<?php

include ("jwt.php");

$headers = getallheaders();

//check if token is missing
if(!isset($headers["Authorization"])){
echo json_encode([
    "response" => "error",
    "message" => "Token Missing"
]);
exit;
}

//remove bearer if there is
$token = str_replace("Bearer ", "", $headers["Authorization"]);


$data = verifyJWT($token);

if(!$data){
    echo json_encode([
        "response" => "error",
        "message" => "Invalid Token"
    ]);
    exit;
}

$viewProducts = mysqli_query($conn, "SELECT * FROM products");
$products = [];

while ($product = mysqli_fetch_array($viewProducts)) {
    $products[] = [
            "product code" => $product['product_code'],
            "product name" => $product['product_name'],
            "cost price" => $product['cost_price'],
            "selling_price" => $product['selling_price'],
            "tax %" => $product['tax']
        ];
}

echo json_encode([
    "message" => "All Products",
    "products" => $products
]);

?>