<?php
require "../../config/connection.php";
require "jwt.php";

header("Content-Type: application/json");
$headers = getallheaders();

if (!isset($headers['Authorization'])) {
    echo json_encode([
        "response" => "error",
        "message" => "Token Missing"
    ]);
    exit;
}

$token = str_replace("Bearer ", "", $headers['Authorization']);

$user = verifyJWT($token);

if (!$user) {
    echo json_encode([
        "response" => "error",
        "message" => "Invalid Token"
    ]);
    exit;
}

$user_id = $user['user_id'];
$user_name = $user['user_name'];


$data = json_decode(file_get_contents("php://input"), true);

$contact_id = $data['contact_id'] ?? '';
$invoice_no = $data['invoice_no'] ?? '';
$invoice_date = $data['invoice_date'] ?? '';
$due_date = $data['due_date'] ?? '';    

$items = $data['items'] ?? [];
$subtotal = 0;
$tax_total = 0;
$grand_total = 0;

if (empty($items) || !is_array($items)) {
    $errors['items'] = "At least one product is required";
}

$status = $data['status'] ?? '';

$created_at = date('Y-m-d H:i:s'); 



$errors = [];

if (empty($contact_id)) {
    $errors['contact_id'] = "Contact Id is required";
}

if (empty($invoice_no)) {
    $errors['invoice_no'] = "Invoice Number is required";
}

if (empty($invoice_date)) {
    $errors['invoice_date'] = "Invoice Date is required";
}

if (empty($due_date)) {
    $errors['due_date'] = "Due Date is required";
}

if (empty($subtotal)) {
    $errors['subtotal'] = "Subtotal is required";
}
if (empty($tax_total)) {
    $errors['tax_total'] = "Tax total is required";
}
if (empty($grand_total)) {
    $errors['grand_total'] = "Grand total is required";
}
if (empty($status)) {
    $errors['status'] = "Status is required";
}

$invoice_no = mysqli_real_escape_string($conn, $invoice_no);

$checkInvoiceNo = mysqli_query($conn, "SELECT * FROM invoices WHERE invoice_no = '$invoice_no'");

if (!empty($errors)) {
    echo json_encode([
        "response" => "error",
        "errors" => $errors
    ]);
    exit;
}


$insertInvoice = mysqli_query($conn, "INSERT INTO `invoices` (`contact_id`, `invoice_no`, `invoice_date`, `due_date`, `subtotal`, `tax_total`, `grand_total`, `status`, `created_at`, `created_by`) 
                                                        VALUES ('$contact_id', '$invoice_no', '$invoice_date', '$due_date', '$subtotal', '$tax_total', '$grand_total', '$status', '$created_at', '$user_name')");

if ($insertInvoice) {
    echo json_encode([
        "Message" => "Invoice Created Successfully"
    ]);
} else {
    echo json_encode([
        "response" => "error",
        "message" => "Failed to create invoice"
    ]);
}



?>