<?php

include ("jwt.php");

$headers = getallheaders();

//check if token is missing
if(!isset($headers["Authorization"])){
echo json_encode([
    "response" => "error",
    "message" => "Token Missing"
]);
exit;
}

//remove bearer if there is
$token = str_replace("Bearer ", "", $headers["Authorization"]);


$data = verifyJWT($token);

if(!$data){
    echo json_encode([
        "response" => "error",
        "message" => "Invalid Token"
    ]);
    exit;
}

$viewContacts = mysqli_query($conn, "SELECT * FROM contacts");

$contacts = [];

while ($row = mysqli_fetch_assoc($viewContacts)) {
    $contacts[] = [
        "Name" => $row['name'],
        "Number" => $row['number'],
        "Email" => $row['email'],
        "Company" => $row['company'],
        "gst" => $row['gst'],
        "address" => $row['address']
    ];
}

echo json_encode([
    "message" => "All Contacts",
    "contacts" => $contacts
]);




?>